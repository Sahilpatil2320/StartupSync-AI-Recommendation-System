
import {
    Bookmark,
    Check,
    ExternalLink,
    Filter,
    MapPin,
    Rocket,
    Search,
    UsersRound,
    X,
} from "lucide-react";
import { useCallback, useEffect, useMemo, useState } from "react";
import api from "../../../services/api";
import { getRecommendations } from "../../../services/aiApi";
import "./InvestorDiscoverStartups.css";

const getProfileId = (profile) =>
    String(
        profile?._id ||
        profile?.id ||
        profile?.userId?._id ||
        profile?.userId?.id ||
        profile?.userId ||
        profile?.user?._id ||
        profile?.user?.id ||
        ""
    );

const getName = (profile) =>
    profile?.startupName ||
    profile?.companyName ||
    profile?.name ||
    profile?.userId?.name ||
    profile?.user?.name ||
    profile?.fullName ||
    "Startup";

const getIndustry = (profile) =>
    profile?.industry || profile?.domain || profile?.sector || "";

const getStage = (profile) =>
    profile?.fundingStage ||
    profile?.startupStage ||
    profile?.stage ||
    profile?.businessStage ||
    "";

const getLocation = (profile) => {
    if (typeof profile?.location === "string") return profile.location;

    if (profile?.location && typeof profile.location === "object") {
        return [
            profile.location.city,
            profile.location.state,
            profile.location.country,
        ]
            .filter(Boolean)
            .join(", ");
    }

    return [profile?.city, profile?.state, profile?.country]
        .filter(Boolean)
        .join(", ");
};

const getDescription = (profile) =>
    profile?.tagline ||
    profile?.description ||
    profile?.startupDescription ||
    profile?.businessDescription ||
    "No startup description provided.";

const getFunding = (profile) =>
    profile?.fundingSought ??
    profile?.fundingRequired ??
    profile?.fundingNeeded ??
    profile?.investmentRequired ??
    profile?.fundingAmount ??
    "";

const getTeamSize = (profile) =>
    profile?.teamSize ??
    profile?.numberOfEmployees ??
    profile?.employees ??
    "";

const getFounded = (profile) =>
    profile?.foundedYear || profile?.founded || profile?.yearFounded || "";

const getRecommendationItems = (response) => {
    const root = response?.data;
    const candidates = [
        root?.data?.recommendations,
        root?.data?.founders,
        root?.data?.results,
        root?.recommendations,
        root?.founders,
        root?.results,
        root?.data,
    ];

    return candidates.find(Array.isArray) || [];
};

const getRecommendationId = (item) =>
    String(
        item?.founderId ||
        item?.founder_id ||
        item?.profileId ||
        item?.profile_id ||
        item?.userId?._id ||
        item?.userId ||
        item?.user_id ||
        item?._id ||
        item?.id ||
        ""
    );

const getRecommendationName = (item) =>
    item?.startupName ||
    item?.companyName ||
    item?.name ||
    item?.founder_name ||
    item?.startup_name ||
    item?.founder?.startupName ||
    item?.founder?.name ||
    "";

const getRecommendationScore = (item) => {
    const score =
        item?.matchScore ??
        item?.match_score ??
        item?.similarity_score ??
        item?.similarity ??
        item?.score ??
        item?.confidence;

    if (typeof score !== "number" || !Number.isFinite(score)) return null;

    return Math.round(
        Math.max(0, Math.min(100, score >= 0 && score <= 1 ? score * 100 : score))
    );
};

const extractProfiles = (response) => {
    const data = response?.data;

    if (Array.isArray(data)) return data;
    if (Array.isArray(data?.founders)) return data.founders;
    if (Array.isArray(data?.profiles)) return data.profiles;
    if (Array.isArray(data?.data)) return data.data;

    return [];
};

function InvestorDiscoverStartups() {
    const [founders, setFounders] = useState([]);
    const [recommendations, setRecommendations] = useState([]);
    const [searchTerm, setSearchTerm] = useState("");
    const [industry, setIndustry] = useState("All Industries");
    const [stage, setStage] = useState("All Stages");
    const [location, setLocation] = useState("All Locations");
    const [sortBy, setSortBy] = useState("name");
    const [savedStartups, setSavedStartups] = useState([]);
    const [connectedStartups, setConnectedStartups] = useState([]);
    const [loading, setLoading] = useState(true);
    const [aiLoading, setAiLoading] = useState(true);
    const [error, setError] = useState("");
    const [aiError, setAiError] = useState("");
    const [connectingId, setConnectingId] = useState("");
    const [selectedFounder, setSelectedFounder] = useState(null);

    const fetchFounders = useCallback(async () => {
        setLoading(true);
        setError("");

        try {
            const token = localStorage.getItem("startupsync_token");

            if (!token) {
                throw new Error("Please log in again to view founder profiles.");
            }

            const response = await api.get("/profiles/founders", {
                headers: { Authorization: `Bearer ${token}` },
            });

            setFounders(extractProfiles(response));
        } catch (err) {
            setError(
                err.response?.data?.message ||
                err.message ||
                "Unable to load founder profiles."
            );
            setFounders([]);
        } finally {
            setLoading(false);
        }
    }, []);

    const fetchRecommendations = useCallback(async () => {
        setAiLoading(true);
        setAiError("");

        try {
            const token = localStorage.getItem("startupsync_token");

            if (!token) {
                throw new Error("Please log in again to view AI recommendations.");
            }

            let userId = "";

            try {
                const payload = token.split(".")[1];
                const normalized = payload.replace(/-/g, "+").replace(/_/g, "/");
                const decoded = JSON.parse(window.atob(normalized));
                userId =
                    decoded.userId || decoded.id || decoded._id || decoded.sub || "";
            } catch {
                throw new Error("Could not identify your account from the login token.");
            }

            if (!userId) {
                throw new Error("Could not identify your account from the login token.");
            }

            const response = await getRecommendations("investor", "founders", userId);
            setRecommendations(getRecommendationItems(response).slice(0, 5));
        } catch (err) {
            setAiError(
                err.response?.data?.message ||
                err.message ||
                "Unable to load AI recommendations."
            );
            setRecommendations([]);
        } finally {
            setAiLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchFounders();
        fetchRecommendations();
    }, [fetchFounders, fetchRecommendations]);

    const industries = useMemo(
        () => [
            "All Industries",
            ...new Set(founders.map(getIndustry).filter(Boolean)),
        ],
        [founders]
    );

    const stages = useMemo(
        () => ["All Stages", ...new Set(founders.map(getStage).filter(Boolean))],
        [founders]
    );

    const locations = useMemo(
        () => [
            "All Locations",
            ...new Set(
                founders
                    .map(getLocation)
                    .filter(Boolean)
                    .map((value) => value.split(",").pop().trim())
            ),
        ],
        [founders]
    );

    const recommendedFounders = useMemo(() => {
        const matched = recommendations
            .map((recommendation) => {
                const recommendationId = getRecommendationId(recommendation);
                const recommendationName = getRecommendationName(recommendation)
                    .trim()
                    .toLowerCase();

                const founder = founders.find((item) => {
                    const profileId = getProfileId(item);
                    const linkedUserId =
                        typeof item.userId === "object"
                            ? String(item.userId?._id || item.userId?.id || "")
                            : String(item.userId || "");

                    const idMatches =
                        recommendationId &&
                        [profileId, linkedUserId].some(
                            (id) => id && id === recommendationId
                        );

                    const nameMatches =
                        recommendationName &&
                        getName(item).trim().toLowerCase() === recommendationName;

                    return idMatches || nameMatches;
                });

                if (!founder) return null;

                return {
                    ...founder,
                    _aiScore: getRecommendationScore(recommendation),
                };
            })
            .filter(Boolean);

        return matched.filter(
            (founder, index) =>
                matched.findIndex(
                    (item) => getProfileId(item) === getProfileId(founder)
                ) === index
        );
    }, [founders, recommendations]);

    const recommendedIds = useMemo(
        () => new Set(recommendedFounders.map(getProfileId)),
        [recommendedFounders]
    );

    const remainingFounders = useMemo(() => {
        const search = searchTerm.toLowerCase().trim();

        const filtered = founders.filter((founder) => {
            if (recommendedIds.has(getProfileId(founder))) return false;

            const searchableText = [
                getName(founder),
                getIndustry(founder),
                getStage(founder),
                getLocation(founder),
                getDescription(founder),
            ]
                .join(" ")
                .toLowerCase();

            return (
                (!search || searchableText.includes(search)) &&
                (industry === "All Industries" || getIndustry(founder) === industry) &&
                (stage === "All Stages" || getStage(founder) === stage) &&
                (location === "All Locations" ||
                    getLocation(founder).toLowerCase().includes(location.toLowerCase()))
            );
        });

        return [...filtered].sort((a, b) => {
            if (sortBy === "name") return getName(a).localeCompare(getName(b));
            if (sortBy === "industry")
                return getIndustry(a).localeCompare(getIndustry(b));
            if (sortBy === "stage") return getStage(a).localeCompare(getStage(b));
            if (sortBy === "location")
                return getLocation(a).localeCompare(getLocation(b));
            if (sortBy === "newest")
                return Number(getFounded(b) || 0) - Number(getFounded(a) || 0);
            return 0;
        });
    }, [founders, recommendedIds, searchTerm, industry, stage, location, sortBy]);

    const toggleSave = (id) => {
        if (!id) return;

        setSavedStartups((current) =>
            current.includes(id)
                ? current.filter((item) => item !== id)
                : [...current, id]
        );
    };

    const expressInterest = async (founder) => {
        const id = getProfileId(founder);
        if (!id || connectedStartups.includes(id) || connectingId) return;

        try {
            setConnectingId(id);
            const token = localStorage.getItem("startupsync_token");

            if (!token) throw new Error("Please log in again.");

            await api.post(
                `/connections/founders/${encodeURIComponent(id)}`,
                {},
                { headers: { Authorization: `Bearer ${token}` } }
            );

            setConnectedStartups((current) =>
                current.includes(id) ? current : [...current, id]
            );
            window.alert("Your interest has been sent successfully.");
        } catch (err) {
            window.alert(
                err.response?.data?.message ||
                err.message ||
                "Unable to send your interest. Please try again."
            );
        } finally {
            setConnectingId("");
        }
    };

    const clearFilters = () => {
        setSearchTerm("");
        setIndustry("All Industries");
        setStage("All Stages");
        setLocation("All Locations");
        setSortBy("name");
    };

    const renderFounderCard = (founder, recommended = false) => {
        const id = getProfileId(founder);
        const isSaved = savedStartups.includes(id);
        const isConnected = connectedStartups.includes(id);
        const score = founder._aiScore;

        return (
            <article className="investor-startup-card" key={id || getName(founder)}>
                <div className="startup-card-top">
                    <div className="startup-logo">
                        <Rocket size={23} />
                    </div>

                    <div className="startup-card-title">
                        <h3>{getName(founder)}</h3>
                        <span>{getIndustry(founder) || "Industry not specified"}</span>
                    </div>

                    <button
                        type="button"
                        className={`startup-save-button ${isSaved ? "startup-save-active" : ""
                            }`}
                        onClick={() => toggleSave(id)}
                        aria-label={isSaved ? "Remove saved startup" : "Save startup"}
                        title={isSaved ? "Remove saved startup" : "Save startup"}
                    >
                        <Bookmark size={19} fill={isSaved ? "currentColor" : "none"} />
                    </button>
                </div>

                {recommended && (
                    <div className="startup-match">
                        <span>AI Recommended</span>
                        {score !== null && score !== undefined && <strong>{score}%</strong>}
                    </div>
                )}

                <p className="startup-tagline">{getDescription(founder)}</p>

                <div className="startup-details">
                    <div className="startup-detail">
                        <MapPin size={16} />
                        <span>{getLocation(founder) || "Location not provided"}</span>
                    </div>

                    <div className="startup-detail">
                        <UsersRound size={16} />
                        <span>
                            {getTeamSize(founder)
                                ? `${getTeamSize(founder)} team members`
                                : "Team size not provided"}
                        </span>
                    </div>

                    <div className="startup-detail">
                        <span className="startup-detail-label">Stage</span>
                        <span>{getStage(founder) || "Not specified"}</span>
                    </div>

                    <div className="startup-detail">
                        <span className="startup-detail-label">Funding</span>
                        <span>
                            {getFunding(founder) === ""
                                ? "Not specified"
                                : String(getFunding(founder))}
                        </span>
                    </div>

                    <div className="startup-detail">
                        <span className="startup-detail-label">Founded</span>
                        <span>{getFounded(founder) || "Not specified"}</span>
                    </div>
                </div>

                <div className="startup-card-actions">
                    <button
                        type="button"
                        className="btn btn-secondary startup-view-button"
                        onClick={() => setSelectedFounder(founder)}
                    >
                        View Profile
                        <ExternalLink size={16} />
                    </button>

                    <button
                        type="button"
                        className={`btn startup-connect-button ${isConnected ? "startup-connected" : "btn-primary"
                            }`}
                        disabled={isConnected || connectingId === id || !id}
                        onClick={() => expressInterest(founder)}
                    >
                        {isConnected ? (
                            <>
                                <Check size={16} />
                                Interest Sent
                            </>
                        ) : connectingId === id ? (
                            "Sending..."
                        ) : (
                            "Express Interest"
                        )}
                    </button>
                </div>
            </article>
        );
    };

    return (
        <div className="investor-discover-page">
            <section className="investor-discover-header">
                <div>
                    <span className="investor-discover-badge">
                        <Rocket size={15} />
                        Startup Discovery
                    </span>
                    <h2>Discover Startups</h2>
                    <p>
                        Discover AI-recommended founders and explore the StartupSync
                        startup ecosystem.
                    </p>
                </div>

                <div className="investor-discover-summary">
                    <strong>{founders.length}</strong>
                    <span>Registered Startups</span>
                </div>
            </section>

            <section style={{ margin: "24px 0 14px" }}>
                <h3>Top 5 AI Recommendations</h3>
                <p>Founders recommended for your investor profile.</p>
            </section>

            {aiLoading ? (
                <p>Loading AI recommendations...</p>
            ) : aiError ? (
                <section className="investor-empty-state">
                    <h3>Recommendations unavailable</h3>
                    <p>{aiError}</p>
                    <button
                        type="button"
                        className="btn btn-primary"
                        onClick={fetchRecommendations}
                    >
                        Retry Recommendations
                    </button>
                </section>
            ) : recommendedFounders.length > 0 ? (
                <section className="investor-startup-grid">
                    {recommendedFounders.slice(0, 5).map((founder) =>
                        renderFounderCard(founder, true)
                    )}
                </section>
            ) : (
                <section className="investor-empty-state">
                    <div className="investor-empty-icon">
                        <Rocket size={28} />
                    </div>
                    <h3>No matched AI recommendations</h3>
                    <p>
                        No AI recommendations matched the registered founder profiles.
                        Check the recommendation IDs and profile links.
                    </p>
                    <button
                        type="button"
                        className="btn btn-secondary"
                        onClick={fetchRecommendations}
                    >
                        Retry
                    </button>
                </section>
            )}

            <section style={{ margin: "32px 0 14px" }}>
                <h3>Explore All Other Startups</h3>
                <p>Search, filter, and sort the remaining registered founder profiles.</p>
            </section>

            <section className="investor-search-panel">
                <div className="investor-search-box">
                    <Search size={19} />
                    <input
                        type="text"
                        placeholder="Search startups, industries or locations..."
                        value={searchTerm}
                        onChange={(event) => setSearchTerm(event.target.value)}
                    />
                    {searchTerm && (
                        <button
                            type="button"
                            className="investor-search-clear"
                            onClick={() => setSearchTerm("")}
                            aria-label="Clear search"
                        >
                            <X size={17} />
                        </button>
                    )}
                </div>

                <div className="investor-filter-title">
                    <Filter size={17} />
                    <span>Filters and Sorting</span>
                </div>

                <div className="investor-filter-grid">
                    <select
                        value={industry}
                        onChange={(event) => setIndustry(event.target.value)}
                    >
                        {industries.map((option) => (
                            <option key={option} value={option}>
                                {option}
                            </option>
                        ))}
                    </select>

                    <select
                        value={stage}
                        onChange={(event) => setStage(event.target.value)}
                    >
                        {stages.map((option) => (
                            <option key={option} value={option}>
                                {option}
                            </option>
                        ))}
                    </select>

                    <select
                        value={location}
                        onChange={(event) => setLocation(event.target.value)}
                    >
                        {locations.map((option) => (
                            <option key={option} value={option}>
                                {option}
                            </option>
                        ))}
                    </select>

                    <select
                        value={sortBy}
                        onChange={(event) => setSortBy(event.target.value)}
                        aria-label="Sort startups"
                    >
                        <option value="name">Sort: Name A–Z</option>
                        <option value="industry">Sort: Industry</option>
                        <option value="stage">Sort: Stage</option>
                        <option value="location">Sort: Location</option>
                        <option value="newest">Sort: Newest Founded</option>
                    </select>

                    {(searchTerm ||
                        industry !== "All Industries" ||
                        stage !== "All Stages" ||
                        location !== "All Locations" ||
                        sortBy !== "name") && (
                            <button
                                type="button"
                                className="investor-clear-filters"
                                onClick={clearFilters}
                            >
                                Clear Filters
                            </button>
                        )}
                </div>
            </section>

            {loading ? (
                <p>Loading founder profiles...</p>
            ) : error ? (
                <section className="investor-empty-state">
                    <h3>Unable to load startups</h3>
                    <p>{error}</p>
                    <button
                        type="button"
                        className="btn btn-primary"
                        onClick={fetchFounders}
                    >
                        Retry
                    </button>
                </section>
            ) : remainingFounders.length > 0 ? (
                <>
                    <p style={{ margin: "18px 0" }}>
                        {remainingFounders.length} other startup
                        {remainingFounders.length !== 1 ? "s" : ""} found
                    </p>
                    <section className="investor-startup-grid">
                        {remainingFounders.map((founder) => renderFounderCard(founder))}
                    </section>
                </>
            ) : (
                <section className="investor-empty-state">
                    <div className="investor-empty-icon">
                        <Search size={28} />
                    </div>
                    <h3>No other startups found</h3>
                    <p>Try changing your search or filter criteria.</p>
                    <button
                        type="button"
                        className="btn btn-primary"
                        onClick={clearFilters}
                    >
                        Clear Filters
                    </button>
                </section>
            )}

            {selectedFounder && (
                <div
                    className="investor-notification-modal-overlay"
                    onClick={() => setSelectedFounder(null)}
                >
                    <div
                        className="investor-notification-modal"
                        onClick={(event) => event.stopPropagation()}
                    >
                        <div className="investor-notification-modal-header">
                            <div className="investor-notification-modal-icon investor-notification-icon-startup">
                                <Rocket size={22} />
                            </div>
                            <button
                                type="button"
                                onClick={() => setSelectedFounder(null)}
                                aria-label="Close profile"
                            >
                                <X size={19} />
                            </button>
                        </div>

                        <div className="investor-notification-modal-body">
                            <h3>{getName(selectedFounder)}</h3>
                            <p>
                                <strong>Industry:</strong>{" "}
                                {getIndustry(selectedFounder) || "Not specified"}
                            </p>
                            <p>
                                <strong>Stage:</strong>{" "}
                                {getStage(selectedFounder) || "Not specified"}
                            </p>
                            <p>
                                <strong>Location:</strong>{" "}
                                {getLocation(selectedFounder) || "Not specified"}
                            </p>
                            <p>
                                <strong>Team size:</strong>{" "}
                                {getTeamSize(selectedFounder) || "Not specified"}
                            </p>
                            <p>
                                <strong>Funding sought:</strong>{" "}
                                {getFunding(selectedFounder) || "Not specified"}
                            </p>
                            <p>
                                <strong>Description:</strong>{" "}
                                {getDescription(selectedFounder)}
                            </p>
                        </div>

                        <div className="investor-notification-modal-footer">
                            <button
                                type="button"
                                className="btn btn-secondary"
                                onClick={() => setSelectedFounder(null)}
                            >
                                Close
                            </button>
                            <button
                                type="button"
                                className="btn btn-primary"
                                onClick={() => {
                                    setSelectedFounder(null);
                                    expressInterest(selectedFounder);
                                }}
                            >
                                Express Interest
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}

export default InvestorDiscoverStartups;